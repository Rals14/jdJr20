package binaria;

public class Esquela {
    //Atributos: caracteristicas relevantes de mi objeto
    String licencia;
    int monto;
    String razon;

    //Constructor: inicializa los atributos de la clase
    public Esquela(String licencia, int monto, String razon) {
        this.licencia = licencia;
        this.monto = monto;
        this.razon = razon;
    }


}
