package binaria;

import java.util.Arrays;
import java.util.Scanner;

public class SistemaEsquelas {

    public static void main(String[] args) {
        // Crear un objeto de la clase Esquela

        Esquela[] esquelas = {
            new Esquela("123456789", 50, "Exceso de velocidad"),
            new Esquela("987654321", 100, "Conducir en estado de ebriedad"),
            new Esquela("111111111", 75, "Pasarme un semáforo en rojo"),
            new Esquela("222222222", 30, "Estacionarse en lugar prohibido"),
        };

        // Ordenar las esquelas por licencia
        Arrays.sort(esquelas, (Esquela e1, Esquela e2) -> e1.licencia.compareTo(e2.licencia));


        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese licencia a verificar por esquela:");
        String licencia = sc.nextLine();
    }

    private static int buscarEsquelaPorLicencia(Esquela[] esquelas, String licencia) {
        //indices del array
        int inicio = 0;
        int fin = esquelas.length - 1;
        return 0;
    }
}
